import tkinter as tk
from tkinter import ttk, messagebox
import webbrowser


def open_url():
    url = url_entry.get().strip()
    if not url:
        messagebox.showwarning("Input Error", "Please enter a URL.")
        return

    if not url.startswith("http"):
        url = "http://" + url  # Append if missing
    webbrowser.open(url)


def google_search():
    query = search_entry.get().strip()
    if not query:
        messagebox.showwarning("Input Error", "Please enter a search term.")
        return

    search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
    webbrowser.open(search_url)


root = tk.Tk()
root.title("Mini Web Browser")
root.geometry("500x250")
root.resizable(False, False)


style = ttk.Style()
style.configure("TLabel", font=("Arial", 12))
style.configure("TButton", font=("Arial", 11))
style.configure("TEntry", font=("Arial", 11))


title_label = ttk.Label(root, text="Mini Web Browser using Tkinter", font=("Arial", 14, "bold"))
title_label.pack(pady=10)


url_frame = ttk.Frame(root)
url_frame.pack(pady=5)

url_label = ttk.Label(url_frame, text="Enter URL:")
url_label.pack(side=tk.LEFT, padx=5)

url_entry = ttk.Entry(url_frame, width=40)
url_entry.pack(side=tk.LEFT, padx=5)

go_button = ttk.Button(url_frame, text="Go", command=open_url)
go_button.pack(side=tk.LEFT)


search_frame = ttk.Frame(root)
search_frame.pack(pady=20)

search_label = ttk.Label(search_frame, text="Google Search:")
search_label.pack(side=tk.LEFT, padx=5)

search_entry = ttk.Entry(search_frame, width=40)
search_entry.pack(side=tk.LEFT, padx=5)

search_button = ttk.Button(search_frame, text="Search", command=google_search)
search_button.pack(side=tk.LEFT)


root.mainloop()
